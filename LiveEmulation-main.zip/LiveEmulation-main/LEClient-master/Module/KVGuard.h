#pragma once
class KVProtection {
public:
	//static std::vector <const char*> WhiteListedModules;
	static void Setup();
};