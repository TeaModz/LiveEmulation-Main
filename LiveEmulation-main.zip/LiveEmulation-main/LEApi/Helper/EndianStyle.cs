﻿namespace FullXboxAPI._0
{
    public enum EndianStyle
    {
        LittleEndian,
        BigEndian
    }
}
