#include "stdafx.h"

Profiler g_profiler;

Profiler* GetProfiler() {
	return &g_profiler;
}