#include "stdafx.h"

void Option::Input(int pos) {}
void Option::Render(int pos) {}
void Option::RenderSelected(int pos) {}
void Option::LoadFromConfig(ConfigResolvedItems resolved) {}

void nullsub(){}
bool nullsub_b() {}

bool defaultRequirement() {
	return true;
}