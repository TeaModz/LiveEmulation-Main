#pragma once

class Encryption {
public:
};