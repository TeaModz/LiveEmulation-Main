﻿namespace Security {
    public enum EndianStyle {
        LittleEndian,
        BigEndian
    }
}

