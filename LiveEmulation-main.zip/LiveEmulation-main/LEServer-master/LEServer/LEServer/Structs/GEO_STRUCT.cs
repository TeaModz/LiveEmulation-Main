﻿namespace LE {
        public struct GEO_STRUCT {

            public string geoplugin_request { get; set; } // ip
            public string geoplugin_latitude { get; set; }
            public string geoplugin_longitude { get; set; }
            public string geoplugin_region { get; set; } // state
            public string geoplugin_city { get; set; }  // city
            public string geoplugin_countryName { get; set; } // country name
    }
}
