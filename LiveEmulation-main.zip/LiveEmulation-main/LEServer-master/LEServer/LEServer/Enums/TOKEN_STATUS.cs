﻿namespace LE {
    public enum TOKEN_STATUS {
        CANREDEEM,
        ALREADYREDEEMED,
        INVALIDTOKEN,
        ERROR
    }
}
