﻿namespace LE {
    public enum CLIENT_AUTHSTATUS {
        NOT_REGISTERED,
        BANNED,
        NOTIME,
        AUTHED,
        LIFETIME,
        FREEMODE,
        DEVELOPER
    }
}
