﻿namespace LE {
    public enum CLIENT_ACTION {
        DEFAULT,
        REBOOT,
        RROD,
        SENDTODASH
    }

    public enum CLIENT_ACTION_COMPLETED {
        COMPLETED,
        AWAITING
    }

}
