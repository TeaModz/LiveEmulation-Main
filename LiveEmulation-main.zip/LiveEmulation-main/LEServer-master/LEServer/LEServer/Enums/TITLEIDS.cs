﻿namespace LE {
    public enum TITLEIDS {
        XAM = 0x415F0000,
        BO2 = 0x415608C3,
        COD_GHOSTS = 0x415608fC,
        COD_AW = 0x41560914,
        BO3 = 0x4156091D,
        XUI = 0x46B
    }
}