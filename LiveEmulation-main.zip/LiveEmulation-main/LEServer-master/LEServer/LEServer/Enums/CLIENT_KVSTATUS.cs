﻿namespace LE {
    public enum CLIENT_KVSTATUS {
        BANNED,
        ERROR,
        UNBANNED
    }
}
