﻿namespace LE {
    public enum CLIENT_KVTYPE {
        CORONA,
        XENON,
        ZEPHYR,
        FALCON,
        JASPER,
        TRINITY
    }
}
