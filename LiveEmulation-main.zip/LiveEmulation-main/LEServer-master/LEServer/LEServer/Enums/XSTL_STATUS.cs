﻿
namespace LE {
    public enum PACKET_STATUS {
        ERROR,
        SUCCESS,
        UPDATE
    }
}