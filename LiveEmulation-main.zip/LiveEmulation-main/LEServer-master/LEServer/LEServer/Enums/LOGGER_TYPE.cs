﻿namespace LE{
    enum LOGGER_TYPE{
        NONE = 0,
        ERROR = 1,
        WARNING = 2,
        INITIALIZER = 3
    }
}
