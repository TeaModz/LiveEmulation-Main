This will upload lasting salts to API from xbox 360. 
copy sram folder to /hdd then run sram-dumper.xex like a game. 
Input your IP & port number into dumper.ini before doing so. Take off any plugin files before using. 
